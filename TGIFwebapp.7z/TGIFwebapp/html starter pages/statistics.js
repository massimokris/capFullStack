var statistics = {
    
    "numDemocrats": 0,
                
    "numRepublicans": 0,
                
    "numIndependents": 0,
    
    "votesDemocrats": 0,
    
    "votesRepublicans": 0,
    
    "votesIndependents": 0,
    
    "votestotal": 0,
    
    "leastLoyal": [],
    
    "mostLoyal": [],
    
    "mostAttendance": [],
    
    "leastAttendance": []
    
}